package com.ems.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

//Second Back controller
@Controller
@RequestMapping("/ecc")
public class EventCreationController {
	
	
	
	public EventCreationController() {
		System.out.println("Controller 2");                  
	}

	@GetMapping("/message")
	@ResponseBody
	public String welcome() {
		return "hi Please add an Event";
	}

}
