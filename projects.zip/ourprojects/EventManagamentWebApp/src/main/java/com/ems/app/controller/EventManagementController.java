package com.ems.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


//creating Back Controller
@Controller
@RequestMapping("/emc") //Controller Level End Point
public class EventManagementController {
	
	
	public EventManagementController() {
		System.out.println("controller");
	}

	//creating 
	@RequestMapping(value="/message",method = RequestMethod.GET)
	
	//Annotation that indicates a method return value should be bound to the web response body. 
	//		Supported for annotated handler methods. 
	@ResponseBody
	public String getMessage() {
		return "hi Welcome to the Hell of Spring MVC";
	}
}
