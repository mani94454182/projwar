package com.ems.app.model;

public class Event {
	

}
