package com.da.beans;

import java.sql.Date;

public class AppointmentTransferBeans {
	
 private String patientId;
 private Date patientAppointmentDate;
 private String pCoupNum;
 private String patientSlot;
public String getPatientId() {
	return patientId;
}
public void setPatientId(String patientId) {
	this.patientId = patientId;
}
public Date getPatientAppointmentDate() {
	return patientAppointmentDate;
}
public void setPatientAppointmentDate(Date patientAppointmentDate) {
	this.patientAppointmentDate = patientAppointmentDate;
}
public String getpCoupNum() {
	return pCoupNum;
}
public void setpCoupNum(String pCoupNum) {
	this.pCoupNum = pCoupNum;
}
public String getPatientSlot() {
	return patientSlot;
}
public void setPatientSlot(String patientSlot) {
	this.patientSlot = patientSlot;
}
	
}
	
	