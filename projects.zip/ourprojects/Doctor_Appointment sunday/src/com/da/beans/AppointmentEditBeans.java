package com.da.beans;

public class AppointmentEditBeans {
	private int patientId;
	private java.sql.Date patientAppointmentDate;
	private String patientCoup;
	
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public java.sql.Date getPatientAppointmentDate() {
		return patientAppointmentDate;
	}
	public void setPatientAppointmentDate(java.sql.Date patientAppointmentDate) {
		this.patientAppointmentDate = patientAppointmentDate;
	}
	public String getPatientCoup() {
		return patientCoup;
	}
	public void setPatientCoup(String patientCoup) {
		this.patientCoup = patientCoup;
	}

}
