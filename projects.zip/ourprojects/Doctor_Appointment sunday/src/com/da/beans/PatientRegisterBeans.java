package com.da.beans;

import java.sql.Date;

public class PatientRegisterBeans {
	private int patientId;
	private int doctorId;
	private Date patientAppointDate;
	private String patientSlot;
	private String patientCouponNo;
	private String patientReason;
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public Date getPatientAppointDate() {
		return patientAppointDate;
	}
	public void setPatientAppointDate(Date patientAppointDate) {
		this.patientAppointDate = patientAppointDate;
	}
	public String getPatientSlot() {
		return patientSlot;
	}
	public void setPatientSlot(String patientSlot) {
		this.patientSlot = patientSlot;
	}
	public String getPatientCouponNo() {
		return patientCouponNo;
	}
	public void setPatientCouponNo(String patientCouponNo) {
		this.patientCouponNo = patientCouponNo;
	}
	public String getPatientReason() {
		return patientReason;
	}
	public void setPatientReason(String patientReason) {
		this.patientReason = patientReason;
	}
	
}
