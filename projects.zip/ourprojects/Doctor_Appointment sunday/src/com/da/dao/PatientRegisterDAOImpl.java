package com.da.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.da.beans.PatientRegisterBeans;

public class PatientRegisterDAOImpl implements PatientRegisterDAO {

	 public boolean addPatient(PatientRegisterBeans obj)
	 {
		 boolean b =false;
		 try
		 {
			 Connection con = DBUtil.getConnection();
			 
			 PreparedStatement ps = con.prepareStatement("insert into Patient25 values(?,?,?,?,?,?)");
			 ps.setInt(1, obj.getPatientId());
			 ps.setInt(2, obj.getDoctorId());
			  
		    ps.setDate(3, obj.getPatientAppointDate());
			  ps.setString(4, obj.getPatientSlot());
			  ps.setString(5, obj.getPatientCouponNo());
			  ps.setString(6, obj.getPatientReason());
			  
			  
			  int i = ps.executeUpdate();
			if(i>0)
			{
				b = true;
			}
		 }catch(Exception e)
		 {
			 System.out.println(e.getMessage());
		 }
		 return b;
	 }
	
}