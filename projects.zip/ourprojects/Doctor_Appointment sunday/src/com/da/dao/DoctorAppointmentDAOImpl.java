package com.da.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.da.beans.AppointmentFixBeans;

public class DoctorAppointmentDAOImpl implements DoctorAppointmentDAO {

	 public boolean addAppointment(AppointmentFixBeans obj)
	 {
		 boolean b =false;
		
		
 try
		 {
			 Connection con = DBUtil.getConnection();
			 
			 PreparedStatement ps = con.prepareStatement("insert into Patient111 values(?,?,?,?,?,?)");
			
			  ps.setString(1, obj.getPatientId());
			  ps.setString(2, obj.getPatientName());
			  ps.setInt(3, obj.getPatientAge());
			  ps.setLong(4, obj.getPatientPhoneNumber());
			  ps.setString(5, obj.getPatientGender());
			  ps.setString(6, obj.getPatientAddress());
		      
			  
			  int i = ps.executeUpdate();
			if(i>0)
			{
				b = true;
			}
		 }catch(Exception e)
		 {
			 System.out.println(e.getMessage());
		 }
		 return b;
	 }
	
}

