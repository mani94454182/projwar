package com.da.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import com.da.beans.LoginBeans;

public class LoginDAOImpl implements LoginDAO{
		
		public String check(LoginBeans lb){
			ResultSet rs=null; 
		
			String role=null;
			
			
			try{
				Connection con=DBUtil.getConnection();
				System.out.println("select from database");

				PreparedStatement ps = con.prepareStatement("select * from login15 where username=? and password=?");
				
				System.out.println("selhftrabase");
				ps.setString(1,lb.getUserName());
				ps.setString(2,lb.getPassword());
		
				rs=ps.executeQuery();
				
				while(rs.next()){
					role=rs.getString(3);
					System.out.println("selhfhtyutrabase");
				}
				}
			catch (Exception e) {
					
				System.out.println(e.getMessage());
			}
				return role;
		}
}