package com.da.dao;

import com.da.beans.AppointmentTransferBeans;

public interface AppointmentTransferDAO {
	public boolean approve(AppointmentTransferBeans obj);
}
