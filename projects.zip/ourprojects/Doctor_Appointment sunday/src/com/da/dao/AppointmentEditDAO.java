package com.da.dao;

import java.util.List;

import com.da.beans.PatientRegisterBeans;


public interface AppointmentEditDAO {
      public List<PatientRegisterBeans> editAppointment();
}
	
