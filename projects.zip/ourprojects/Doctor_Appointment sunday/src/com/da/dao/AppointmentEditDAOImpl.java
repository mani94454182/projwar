package com.da.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;
import java.sql.Statement;
import com.da.beans.PatientRegisterBeans;

public class AppointmentEditDAOImpl implements AppointmentEditDAO 
{
	 public List<PatientRegisterBeans> editAppointment()
	
	
	{
		Connection con=null;
		List<PatientRegisterBeans> li=null;
		 
			
			
		try{
			
			con=DBUtil.getConnection();
			PatientRegisterBeans pb1 = null;
			ResultSet rs=null;
			li=new ArrayList<PatientRegisterBeans >();
			Statement st=con.createStatement();
			rs=st.executeQuery("Select * from patient25");
			while(rs.next()){
				pb1=new PatientRegisterBeans();
				pb1.setPatientId(rs.getInt(1));
				pb1.setDoctorId(rs.getInt(2));
				pb1.setPatientAppointDate(rs.getDate(3));
				pb1.setPatientSlot(rs.getString(4));
				pb1.setPatientCouponNo(rs.getString(5));
				pb1.setPatientReason(rs.getString(6));
			
				li.add(pb1);
				
				
			}
			}
		catch(Exception e){
			System.out.println(e.getMessage());
		
		
		
	}
		return li;
		}
}