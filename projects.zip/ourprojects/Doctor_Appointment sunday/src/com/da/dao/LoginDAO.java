package com.da.dao;

import com.da.beans.LoginBeans;

public interface LoginDAO {
	public String check(LoginBeans obj);

}
