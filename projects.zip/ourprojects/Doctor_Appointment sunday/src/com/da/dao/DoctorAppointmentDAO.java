package com.da.dao;

import com.da.beans.AppointmentFixBeans;


public interface DoctorAppointmentDAO {
    public boolean addAppointment(AppointmentFixBeans obj);
}