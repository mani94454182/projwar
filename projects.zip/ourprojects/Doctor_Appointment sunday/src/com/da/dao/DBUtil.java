package com.da.dao;
import java.sql.Connection;
import java.sql.DriverManager;
public class DBUtil {

	  public static Connection getConnection()
	  {
		  Connection con = null;
		    try
		    {
		  Class.forName("oracle.jdbc.driver.OracleDriver");
		  String url = "jdbc:oracle:thin:@172.16.154.10:1521:elp";
		con =  DriverManager.getConnection(url,"elp1673","msat123$");
		  
		    }catch(Exception e)
		    {
		    	System.out.println(e.getMessage());
		    }
		    
		    return con;
	  }
	
}