
package com.da.dao;

import com.da.beans.PatientRegisterBeans;


public interface PatientRegisterDAO {
    public boolean addPatient(PatientRegisterBeans obj);
}