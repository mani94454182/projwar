package com.da.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;


import com.da.beans.AppointmentTransferBeans;

public class AppointmentTransferDAOImpl implements AppointmentTransferDAO{
	public boolean approve(AppointmentTransferBeans obj){
		
		{
			
			boolean b=false;
			Connection con=null;
			PreparedStatement ps=null;
			
			try
			{
				
			con=DBUtil.getConnection();
		   ps  = con.prepareStatement("update patient25 set patientSlot=? where PatientId=? ");
		    ps.setString(1,obj.getPatientSlot());
			ps.setString(2,obj.getPatientId());
			
			int i= ps.executeUpdate();
			if(i>0)
			{
				
				b=true;
			}
			}
			catch(Exception e)
			{
			System.out.println(e.getMessage());
			
			}
	       
			 return b;
		}
		}
	}
	

