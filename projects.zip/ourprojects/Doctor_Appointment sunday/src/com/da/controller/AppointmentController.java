package com.da.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.da.beans.AppointmentFixBeans;
import com.da.beans.AppointmentTransferBeans;
import com.da.beans.PatientRegisterBeans;
import com.da.service.AppointmentEditService;
import com.da.service.AppointmentEditServiceImpl;
import com.da.service.AppointmentTransferService;
import com.da.service.AppointmentTransferServiceImpl;
import com.da.service.PatientRegisterService;
import com.da.service.PatientRegisterServiceImpl;

import com.da.service.DoctorAppointmentService;
import com.da.service.DoctorAppointmentServiceImpl;

import com.da.beans.LoginBeans;
import com.da.service.LoginService;
import com.da.service.LoginServiceImpl;

public class AppointmentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    
    
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = null;
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		pw.println("enter the details");
		
		String operations = request.getParameter("operation");
		
		
		
		
		if (operations == null) {

			response.sendRedirect("/Doctor_Appointment/Index.jsp");
		}
		if(operations.equals("login")){
			session=request.getSession();
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");
			
			LoginBeans lb=new LoginBeans();
			lb.setUserName(userName);
			lb.setPassword(password);
			
			LoginService ls=new LoginServiceImpl();
			String role=ls.check(lb);
			
			RequestDispatcher rb = null;
			
			try{
				if(role.equals("Receptionist")){
					 rb=request.getRequestDispatcher("Appointment.jsp");
					request.setAttribute("successmsg", lb);
					session.setAttribute("loggedinas", "recep");
					rb.include(request, response);
					}
				else if(role.equals("Doctor")){
					 rb=request.getRequestDispatcher("Appointment_View.jsp");
					 session.setAttribute("loggedinas", "doctor");
					request.setAttribute("successmsg", lb);
					rb.include(request, response);
				}
				else{
					rb=request.getRequestDispatcher("Error.jsp");
					request.setAttribute("errormsg", "Connection Error");
					   rb.forward(request, response);
				}
			}catch (Exception e) {
				
				e.printStackTrace();
			}
		}
		
		
		if(operations.equals("add"))
		{
			//1. retireve the paramters
			int patientAge = 0;
			long patientPhoneNo=0;
			String pid = request.getParameter("patientId");
			String pname = request.getParameter("patientName");
			String page = request.getParameter("patientAge");
			String pno = request.getParameter("patientPhoneNumber");
			String pgen = request.getParameter("patientGender");
			String padd = request.getParameter("patientAddress");
			
			patientAge = Integer.parseInt(page);
			
			patientPhoneNo= Long.parseLong(pno);
			
			AppointmentFixBeans ab = new AppointmentFixBeans();
			
			ab.setPatientId(pid);
			ab.setPatientName(pname);
			ab.setPatientAge(patientAge);
			ab.setPatientPhoneNumber(patientPhoneNo);
			ab.setPatientGender(pgen);
			ab.setPatientAddress(padd);

			
			DoctorAppointmentService das = new DoctorAppointmentServiceImpl();
			  boolean b =  das.addAppointment(ab);
			  RequestDispatcher rd = null;
			  System.out.println("cameeeee");
			  if(b)
			  { 
				
				   rd = request.getRequestDispatcher("/Appointment_Fix.jsp");
				  request.setAttribute("successmsg", ab);
				   rd.forward(request, response);
			  }else
			  {
				  rd = request.getRequestDispatcher("/Error.jsp");
				  request.setAttribute("errmsg", "Database Connection Error!");
				   rd.forward(request, response);
			  }
				
		}

		
		
		else if(operations.equals("Register"))
		{
			//1. retireve the paramters
			int patientId = 0;
			int doctorId=0;
			String pid = request.getParameter("patientId");
			String did = request.getParameter("doctorId");
			String pappd = request.getParameter("patientAppointDate");
			String pslot = request.getParameter("patientSlot");
			String pcoup = request.getParameter("patientCouponNo");
			String pres = request.getParameter("patientReason");
			java.sql.Date patientAppointDate=null;
			try
			{
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

			   Date parser = sdf.parse(pappd);

			   patientAppointDate = new java.sql.Date(parser.getTime());
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			
			
			patientId = Integer.parseInt(pid);
			
			doctorId= Integer.parseInt(did);
			
			PatientRegisterBeans pr = new PatientRegisterBeans();
			
			pr.setPatientId(patientId);
			pr.setDoctorId(doctorId);
			pr.setPatientAppointDate(patientAppointDate);
			pr.setPatientSlot(pslot);
			pr.setPatientCouponNo(pcoup);
			pr.setPatientReason(pres);
			
			PatientRegisterService prs = new PatientRegisterServiceImpl();
			  boolean b =  prs.addPatient(pr);
			  RequestDispatcher rd = null;
			  if(b)
			  { 
				
				   rd = request.getRequestDispatcher("/Patient_Register.jsp");
				  request.setAttribute("successmsg", pr);
				   rd.forward(request, response);
			  }else
			  {
				  rd = request.getRequestDispatcher("/Error.jsp");
				  request.setAttribute("errmsg", "Database Connection Error!");
				   rd.forward(request, response);
			  }
			
			
		}
		else if(operations.equals("view"))
		 {
			 System.out.println("hi");
			RequestDispatcher rd=null;
			System.out.println("View Requested");
			
			AppointmentEditService aes=new AppointmentEditServiceImpl();
			List<PatientRegisterBeans> li=aes.editAppointment();
			request.setAttribute("li", li);
			System.out.println("came");
			if(li!=null)
			{
				rd = request.getRequestDispatcher("/Appointment_View.jsp");
				rd.forward(request, response);
			} else 
			{
				rd = request.getRequestDispatcher("/Error.jsp");
				request.setAttribute("errordata", "Unable to FetchData");
				rd.forward(request, response);
				
			}
			
		}
		
		
		else if(operations.equals("transfer"))
		{
			  RequestDispatcher rd = null;
			  System.out.println("hi");
			  String pId=request.getParameter("patientId");
			  String pDate=request.getParameter("patientAppointmentDate");
			  String pCoup=request.getParameter("pCoupNum");
			  String pSlot=request.getParameter("patientSlot");
			  java.sql.Date patientAppointDate=null;
			  
			  try
				{
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

				   Date parser = sdf.parse(pDate);

				   patientAppointDate = new java.sql.Date(parser.getTime());
				}catch(Exception e)
				{
					e.printStackTrace();
				} 
			  	  
		AppointmentTransferBeans at=new AppointmentTransferBeans();
		
		at.setPatientId(pId);
		at.setPatientAppointmentDate( patientAppointDate);
		at.setpCoupNum(pCoup);
		at.setPatientSlot(pSlot);
		
		 System.out.println("advertiser");
		 AppointmentTransferService ats=new AppointmentTransferServiceImpl();
		boolean b=ats.approve(at);
		 
		if(b){
			 System.out.println("ad");
		rd=request.getRequestDispatcher("/Appointment_Transfer.jsp");
		 request.setAttribute("successmsg2", at);
		 
		rd.forward(request, response);
		 
		}
		else
		{
		rd=request.getRequestDispatcher("/Error.jsp");
		rd.forward(request,response);
		
	
		}	
	}
}	
		
	}
		  	

	


	
	


