package com.da.service;

import com.da.beans.PatientRegisterBeans;

public interface PatientRegisterService {
	public boolean addPatient(PatientRegisterBeans obj);
}
