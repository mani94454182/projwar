package com.da.service;

import com.da.beans.AppointmentFixBeans;

public interface DoctorAppointmentService {
	public boolean addAppointment(AppointmentFixBeans obj);
}
