package com.da.service;

import com.da.beans.AppointmentTransferBeans;

public interface AppointmentTransferService {

	public boolean approve(AppointmentTransferBeans obj);
	
	
}
