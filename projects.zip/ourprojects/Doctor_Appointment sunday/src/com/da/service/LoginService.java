package com.da.service;

import com.da.beans.LoginBeans;

public interface LoginService {
public String check(LoginBeans obj);
}

