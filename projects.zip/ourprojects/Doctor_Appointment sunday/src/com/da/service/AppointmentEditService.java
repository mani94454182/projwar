package com.da.service;

import java.util.List;

import com.da.beans.PatientRegisterBeans;

public interface AppointmentEditService {
	public List<PatientRegisterBeans> editAppointment();

}
