package com.da.model;

import com.da.beans.LoginBeans;


public interface LoginModel {
	public String check(LoginBeans obj);

}
