package com.da.model;

import com.da.beans.AppointmentTransferBeans;

public interface AppointmentTransferModel {
	
	public boolean approve(AppointmentTransferBeans obj);

}
