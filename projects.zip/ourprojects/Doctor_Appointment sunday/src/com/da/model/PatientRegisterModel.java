package com.da.model;

import com.da.beans.PatientRegisterBeans;


public interface PatientRegisterModel {
  public boolean addPatient(PatientRegisterBeans obj);
}