package com.da.model;

import com.da.beans.LoginBeans;
import com.da.dao.LoginDAO;
import com.da.dao.LoginDAOImpl;

public class LoginModelImpl implements LoginModel {
	public String check(LoginBeans obj)
	{
		LoginDAO ld=new LoginDAOImpl();
		return ld.check(obj);
	}

}