package com.da.model;

import java.util.List;

import com.da.beans.PatientRegisterBeans;
import com.da.dao.AppointmentEditDAO;
import com.da.dao.AppointmentEditDAOImpl;

public class AppointmentEditModelImpl implements AppointmentEditModel {

	public List<PatientRegisterBeans> editAppointment(){
		
		AppointmentEditDAO dad = new AppointmentEditDAOImpl();
		return dad.editAppointment();
		
	}
}