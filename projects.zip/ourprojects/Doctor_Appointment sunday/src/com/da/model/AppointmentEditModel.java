package com.da.model;

import java.util.List;

import com.da.beans.PatientRegisterBeans;

public interface AppointmentEditModel {
	
	public List<PatientRegisterBeans> editAppointment();

}
