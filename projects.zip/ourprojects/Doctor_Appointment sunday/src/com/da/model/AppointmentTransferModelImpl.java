package com.da.model;

import com.da.beans.AppointmentTransferBeans;
import com.da.dao.AppointmentTransferDAO;
import com.da.dao.AppointmentTransferDAOImpl;


public class AppointmentTransferModelImpl implements AppointmentTransferModel{
	
	public boolean approve(AppointmentTransferBeans obj)
	{
		
		AppointmentTransferDAO dad = new AppointmentTransferDAOImpl();
		return dad.approve(obj);
	
		
		
		
	}

}
