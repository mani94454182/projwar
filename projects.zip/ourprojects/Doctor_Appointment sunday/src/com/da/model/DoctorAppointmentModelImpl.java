package com.da.model;

import com.da.beans.AppointmentFixBeans;
import com.da.dao.DoctorAppointmentDAO;
import com.da.dao.DoctorAppointmentDAOImpl;

public class DoctorAppointmentModelImpl implements DoctorAppointmentModel {

	
	public boolean addAppointment(AppointmentFixBeans obj)
	{
		DoctorAppointmentDAO dad = new DoctorAppointmentDAOImpl();
		  return dad.addAppointment(obj);
		
		}
}
