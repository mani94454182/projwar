
package com.da.model;

import com.da.beans.PatientRegisterBeans;
import com.da.dao.PatientRegisterDAO;
import com.da.dao.PatientRegisterDAOImpl;

public class PatientRegisterModelImpl implements PatientRegisterModel {

	
	public boolean addPatient(PatientRegisterBeans obj)
	{
		PatientRegisterDAO dad = new PatientRegisterDAOImpl();
		  return dad.addPatient(obj);
		
		}
}
