package com.da.model;

import com.da.beans.AppointmentFixBeans;


public interface DoctorAppointmentModel {
  public boolean addAppointment(AppointmentFixBeans obj);
}
