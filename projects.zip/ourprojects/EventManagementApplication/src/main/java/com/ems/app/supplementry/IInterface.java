package com.ems.app.supplementry;

public interface IInterface {
	public void disp();

}
