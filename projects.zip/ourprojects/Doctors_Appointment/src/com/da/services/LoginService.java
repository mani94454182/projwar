package com.da.services;


import com.da.beans.LoginBean;

public interface LoginService {
	public String authenticate(LoginBean bean);
}
