package com.da.services;

import java.util.List;

import com.da.beans.AppointmentViewBean;

public interface AppointmentViewService {
	public List<AppointmentViewBean> getAppointments(AppointmentViewBean viewBean);
	public boolean updateAppointments(AppointmentViewBean viewBean);
	
	public List<AppointmentViewBean> getHistoryWithCouponNo(AppointmentViewBean viewBean);
	public List<AppointmentViewBean> getHistoryWithNamePhone(AppointmentViewBean viewBean);
	public List<AppointmentViewBean> getHistoryWithApptNo(AppointmentViewBean viewBean);
}
