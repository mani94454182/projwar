package com.da.services;

import com.da.beans.AppointmentFixBean;
import com.da.beans.AppointmentTransferBean;
import com.da.models.AppointmentFixModel;
import com.da.models.AppointmentFixModelImpl;

public class AppointmentFixServiceImpl implements AppointmentFixService {
	@Override
	public boolean addAppointment(AppointmentFixBean bean) {
		AppointmentFixModel model=new AppointmentFixModelImpl();
		return model.addAppointment(bean);
		}
	@Override
	public int checkPatientCoupon(AppointmentFixBean bean) {
		AppointmentFixModel model=new AppointmentFixModelImpl();
		return model.checkPatientCoupon(bean);
	}
	
	@Override
	public int checkPatientName_Phone(AppointmentFixBean bean) {
		AppointmentFixModel model=new AppointmentFixModelImpl();
		return model.checkPatientName_Phone(bean);
	}
	@Override
	public boolean addAppointmentOldPatient(AppointmentFixBean bean) {
		AppointmentFixModel model=new AppointmentFixModelImpl();
		return model.addAppointmentOldPatient(bean);
	}
	@Override
	public AppointmentTransferBean transferCheckPatientCoupon(AppointmentFixBean bean) {
		AppointmentFixModel model=new AppointmentFixModelImpl();
		return model.transferCheckPatientCoupon(bean);
	}
	@Override
	public AppointmentTransferBean transferCheckPatientName_Phone(AppointmentFixBean bean) {
		AppointmentFixModel model=new AppointmentFixModelImpl();
		return model.transferCheckPatientName_Phone(bean);
	}
	
	@Override
	public boolean transfer(AppointmentTransferBean transferBean) {
		AppointmentFixModel model=new AppointmentFixModelImpl();
		return model.transfer(transferBean);
	}
}
