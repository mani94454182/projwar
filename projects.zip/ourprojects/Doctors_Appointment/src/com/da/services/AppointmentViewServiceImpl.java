package com.da.services;

import java.util.List;

import com.da.beans.AppointmentViewBean;
import com.da.models.AppointmentViewModel;
import com.da.models.AppointmentViewModelImpl;

public class AppointmentViewServiceImpl implements AppointmentViewService {
	@Override
	public List<AppointmentViewBean> getAppointments(AppointmentViewBean viewBean) {
		AppointmentViewModel viewModel=new AppointmentViewModelImpl();
		return viewModel.getAppointments(viewBean);
	}
	@Override
	public boolean updateAppointments(AppointmentViewBean viewBean) {
		AppointmentViewModel viewModel=new AppointmentViewModelImpl();
		return viewModel.updateAppointments(viewBean);
	}
	@Override
	public List<AppointmentViewBean> getHistoryWithCouponNo(
			AppointmentViewBean viewBean) {
		AppointmentViewModel viewModel=new AppointmentViewModelImpl();
		return viewModel.getHistoryWithCouponNo(viewBean);
	}
	@Override
	public List<AppointmentViewBean> getHistoryWithNamePhone(
			AppointmentViewBean viewBean) {
		AppointmentViewModel viewModel=new AppointmentViewModelImpl();
		return viewModel.getHistoryWithNamePhone(viewBean);
	}
	@Override
	public List<AppointmentViewBean> getHistoryWithApptNo(
			AppointmentViewBean viewBean) {
		AppointmentViewModel viewModel=new AppointmentViewModelImpl();
		return viewModel.getHistoryWithApptNo(viewBean);
	}
	
	
}
