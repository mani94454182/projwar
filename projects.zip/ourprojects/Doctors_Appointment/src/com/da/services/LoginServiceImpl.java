package com.da.services;

import com.da.beans.LoginBean;
import com.da.models.LoginModel;
import com.da.models.LoginModelImpl;

public class LoginServiceImpl implements LoginService {
	@Override
	public String authenticate(LoginBean bean) {
		LoginModel model=new LoginModelImpl();
		return model.authenticate(bean);
	}
}
