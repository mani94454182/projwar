package com.da.services;

import java.util.List;

import com.da.beans.CouponBean;
import com.da.models.CouponGenerationModel;
import com.da.models.CouponGenerationModelImpl;

public class CouponGenerationServiceImpl implements CouponGenerationService{
	@Override
	public List<CouponBean> getDoctors(CouponBean bean) {
			CouponGenerationModel model=new CouponGenerationModelImpl();
			return model.getDoctors(bean);
	}
	@Override
	public List<CouponBean> getCouponNumbers(CouponBean bean) {
		CouponGenerationModel model=new CouponGenerationModelImpl();
		return model.getCouponNumbers(bean);
	}
	@Override
	public String getDoctorName(int doctorId) {
		CouponGenerationModel model=new CouponGenerationModelImpl();
		return model.getDoctorName(doctorId);
	}
}
