package com.da.daos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;


import com.da.beans.LoginBean;

public class LoginDAOImpl implements LoginDAO {
	@Override
	public String authenticate(LoginBean bean) {
		Connection con=null;
		ResultSet set=null;
		String userType=null;
		String userName=bean.getUserName();
		String password=bean.getPassword();
		try {
			con = DBUtil.getConnection();
			System.out.println("Connection Established");
			PreparedStatement ps=con.prepareStatement("SELECT * FROM DALOGIN WHERE USERNAME=? AND PASSWORD=?");			 
			ps.setString(1,userName);
			ps.setString(2, password);
			set=ps.executeQuery();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		try {
			if(set.next()) {
				userType=set.getString("user_type");	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return userType;
	}
}
