package com.da.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.da.beans.AppointmentFixBean;
import com.da.beans.AppointmentTransferBean;

public class AppointmentFixDaoImpl implements AppointmentFixDao {
	@Override
	public boolean addAppointment(AppointmentFixBean bean) {
		String patientName=bean.getPatientName();
		java.sql.Date patientDOB=bean.getPatientDOB();
		int patientSlot=bean.getPatientSlot();
		long patientPhone=bean.getPatientPhone();
		java.sql.Date patientAppointmentDate=bean.getPatientAppointmentDate();
		String patientMail=bean.getPatientMail();
		String patientAddress=bean.getPatientAddress();
		String patientReason=bean.getPatientReason();
		String patientGender=bean.getPatientGender();
		int doctorId=bean.getDoctorId();
		String patientCouponNumber=bean.getPatientCouponNumber();
		String query1="insert into DAPatients (patientid,patientname,dob,gender,email,mobno,address) values(dapatientid.nextval,?,?,?,?,?,?)";
		String query2="insert into DAAppointments (tokenno,patientid,slot,appointment_date,doctor_id,reason) values(?,?,?,?,?,?)";
		PreparedStatement ps=null;
		ResultSet rs=null;
		Connection con=null;	
		boolean b=false;
		try {
			//con.setAutoCommit(false);
			con=DBUtil.getConnection();
			System.out.println("Connection Established");
			con.setAutoCommit(false);
			ps=con.prepareStatement(query1);
			ps.setString(1, patientName);
			ps.setDate(2, patientDOB);
			ps.setString(3, patientGender);
			ps.setString(4, patientMail);
			ps.setLong(5, patientPhone);
			ps.setString(6, patientAddress);
			int i=ps.executeUpdate(); 
			System.out.println("Query1 Executed");
			if(i>0) {
				ps=con.prepareStatement("select patientid from dapatients where patientname=? and mobno=?");
				ps.setString(1, patientName);
				ps.setLong(2, patientPhone);
				rs=ps.executeQuery();
				if(rs.next()) {
					System.out.println("Retrieving pid done");
					int patientId=rs.getInt(1);
					ps=con.prepareStatement(query2);
					ps.setString(1, patientCouponNumber);
					ps.setInt(2, patientId);
					ps.setInt(3, patientSlot);
					ps.setDate(4, patientAppointmentDate);
					ps.setInt(5, doctorId);
					ps.setString(6, patientReason);
					int j=ps.executeUpdate();
					if(j>0) {
						con.commit();
						b=true;
					}
				}
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return b;
	}
	
	@Override
	public int checkPatientCoupon(AppointmentFixBean bean) {
		String patientCouponNumber=bean.getPatientCouponNumber();
		ResultSet rs=null;
		Connection con=null;
		PreparedStatement ps=null;
		int patientId=-1;
		try {
			con=DBUtil.getConnection();
			System.out.println("Connection Established");
			ps=con.prepareStatement("Select patientid from daappointments where tokenno=?");
			ps.setString(1, patientCouponNumber);
			rs=ps.executeQuery();
			System.out.println("Query Executed");
			if(rs.next()){
				patientId=rs.getInt(1);
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return patientId;
	}
	
	@Override
	public int checkPatientName_Phone(AppointmentFixBean bean) {
		String patientName=bean.getPatientName();
		long patientPhone=bean.getPatientPhone();
		ResultSet rs=null;
		Connection con=null;
		PreparedStatement ps=null;
		int patientId=-1;
		try {
			con=DBUtil.getConnection();
			System.out.println("Connection Established");
			ps=con.prepareStatement("Select patientid from dapatients where patientname=? and mobno=?");
			ps.setString(1, patientName);
			ps.setLong(2, patientPhone);
			rs=ps.executeQuery();
			System.out.println("Query Executed");
			if(rs.next()){
				patientId=rs.getInt(1);
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return patientId;
	}
	
	@Override
	public boolean addAppointmentOldPatient(AppointmentFixBean bean) {
		int patientId=bean.getPatientId();
		String patientCouponNumber=bean.getPatientCouponNumber();
		java.sql.Date patientAppointmentDate=bean.getPatientAppointmentDate();
		int patientSlot=bean.getPatientSlot();
		int doctorId=bean.getDoctorId();
		String patientReason=bean.getPatientReason();
		PreparedStatement ps=null;
		Connection con=null;
		boolean b=false;
		try {
			con=DBUtil.getConnection();
			System.out.println("Connection Established");
			ps=con.prepareStatement("insert into DAAppointments (tokenno,patientid,slot,appointment_date,doctor_id,reason) values(?,?,?,?,?,?)");
			ps.setString(1, patientCouponNumber);
			ps.setInt(2, patientId);
			ps.setInt(3, patientSlot);
			ps.setDate(4, patientAppointmentDate);
			ps.setInt(5, doctorId);
			ps.setString(6, patientReason);
			int j=ps.executeUpdate();
			if(j>0){
				b=true;
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return b;
	}

	@Override
	public AppointmentTransferBean transferCheckPatientCoupon(AppointmentFixBean bean) {
		String patientCouponNumber=bean.getPatientCouponNumber();
		ResultSet rs=null;
		Connection con=null;
		PreparedStatement ps=null;
		AppointmentTransferBean transferBean=null;
		try {
			con=DBUtil.getConnection();
			System.out.println("Connection Established");
			ps=con.prepareStatement("Select * from daappointments where tokenno=?");
			ps.setString(1, patientCouponNumber);
			rs=ps.executeQuery();
			System.out.println("Query Executed");
			if(rs.next()){
				transferBean=new AppointmentTransferBean();
				transferBean.setSlot(rs.getInt("slot"));
				transferBean.setPatientAppointmentDate(rs.getDate("appointment_date"));
				transferBean.setAppointmentDate(rs.getString("appointment_date"));
				transferBean.setOldCouponNumber(rs.getString("tokenno"));
				System.out.println("inside if");
				//System.out.println(transferBean.getAppointmentDate());
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return transferBean;
	}

	@Override
	public AppointmentTransferBean transferCheckPatientName_Phone(AppointmentFixBean bean) {
		String patientName=bean.getPatientName();
		long patientPhone=bean.getPatientPhone();
		java.sql.Date appointmentDate=bean.getPatientAppointmentDate();
		ResultSet rs=null;
		Connection con=null;
		PreparedStatement ps=null;
		AppointmentTransferBean transferBean=null;
		try {
			con=DBUtil.getConnection();
			System.out.println("Connection Established");
			ps=con.prepareStatement("Select * from daappointments a,dapatients p where a.patientid=p.patientid and patientname=? and mobno=? and appointment_date=?");
			ps.setString(1, patientName);
			ps.setLong(2, patientPhone);
			ps.setDate(3, appointmentDate);
			rs=ps.executeQuery();
			System.out.println("Query Executed");
			if(rs.next()){
				transferBean=new AppointmentTransferBean();
				transferBean.setSlot(rs.getInt("slot"));
				transferBean.setPatientAppointmentDate(rs.getDate("appointment_date"));
				transferBean.setAppointmentDate(rs.getString("appointment_date"));
				transferBean.setOldCouponNumber(rs.getString("tokenno"));
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return transferBean;
	}
	
	@Override
	public boolean transfer(AppointmentTransferBean transferBean) {
		String newCouponNumber=transferBean.getNewCouponNumber();
		String oldCouponNumber=transferBean.getOldCouponNumber();
		int doctorId=transferBean.getDoctorId();
		int slot=transferBean.getSlot();
		Connection con=null;
		PreparedStatement ps=null;
		boolean b=false;
		try {
			con=DBUtil.getConnection();
			System.out.println("Connection Established");
			ps=con.prepareStatement("Update daappointments set slot=?,tokenno=?,doctor_id=? where tokenno=?");
			ps.setInt(1, slot);
			ps.setString(2, newCouponNumber);
			ps.setInt(3, doctorId);
			ps.setString(4, oldCouponNumber);
			int i=ps.executeUpdate();
			if(i>0){
				b=true;
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return b;
	}
	
}
