package com.da.daos;


import com.da.beans.LoginBean;

public interface LoginDAO {
	public String authenticate(LoginBean bean);
}
