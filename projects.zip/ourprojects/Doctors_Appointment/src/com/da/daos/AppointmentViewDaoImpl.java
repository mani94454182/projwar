package com.da.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.da.beans.AppointmentViewBean;

public class AppointmentViewDaoImpl implements AppointmentViewDao {
	@Override
	public List<AppointmentViewBean> getAppointments(AppointmentViewBean viewBean) {
		List<AppointmentViewBean> list=null;
		ResultSet rs=null;
		PreparedStatement ps=null;
		try {
			Connection con=DBUtil.getConnection();
			System.out.println("Connection Established");
			java.sql.Date date=viewBean.getAppointmentDate();
			String doctorsUserName=viewBean.getDoctorsUserName();
			int doctorId=-1;
			ps=con.prepareStatement("Select id from dadoctors where username=?");
			ps.setString(1, doctorsUserName);
			rs=ps.executeQuery();
			System.out.println("Doctor Id retreival query executed");
			if(rs.next()) {
				doctorId=rs.getInt(1);
			}
			ps=con.prepareStatement("SELECT PATIENTNAME,ROUND(MONTHS_BETWEEN(SYSDATE,DOB)/12) AGE, GENDER,TOKENNO,REASON,P.PATIENTID,MED_HISTORY,SLOT,REPORT FROM DAPATIENTS P,DAAPPOINTMENTS A WHERE P.PATIENTID=A.PATIENTID AND APPOINTMENT_DATE=? AND DOCTOR_ID=? AND REPORT IS NULL");
			ps.setDate(1,date);
			ps.setInt(2, doctorId);
			rs=ps.executeQuery();
			System.out.println("Query Executed");
			viewBean=null;
			list=new ArrayList<AppointmentViewBean>();
			while(rs.next()) {
				viewBean=new AppointmentViewBean();
				viewBean.setPatientName(rs.getString(1));
				viewBean.setPatientAge(rs.getInt(2));
				viewBean.setPatientGender(rs.getString(3));
				viewBean.setPatientCouponNumber(rs.getString(4));
				viewBean.setPatientReason(rs.getString(5));
				viewBean.setPatientId(rs.getInt(6));
				viewBean.setPatientHistory(rs.getString(7));
				viewBean.setPatientSlot(rs.getInt(8));
				viewBean.setPatientReport(rs.getString(9));
				System.out.println(viewBean.getPatientName());
				System.out.println(viewBean.getPatientAge());
				System.out.println(viewBean.getPatientCouponNumber());
				System.out.println(viewBean.getPatientGender());
				System.out.println(viewBean.getPatientId());
				System.out.println(viewBean.getPatientReason());
				System.out.println("History: "+viewBean.getPatientHistory());
				list.add(viewBean);
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}
	
	@Override
	public boolean updateAppointments(AppointmentViewBean viewBean) {
		Connection con=null;
		boolean b=false;
		PreparedStatement ps=null;
		try {
			con=DBUtil.getConnection();
			System.out.println("Connection Established");
			int patientId=viewBean.getPatientId();
			String patientReport=viewBean.getPatientReport();
			String patientHistory=viewBean.getPatientHistory();
			java.sql.Date patientAppointmentDate=viewBean.getAppointmentDate();
			ps=con.prepareStatement("UPDATE DAAPPOINTMENTS SET REPORT=? WHERE PATIENTID=? AND APPOINTMENT_DATE=?");
			ps.setString(1, patientReport);
			ps.setInt(2, patientId);
			ps.setDate(3, patientAppointmentDate);
			int i=ps.executeUpdate();
			System.out.println("Report Updated");
			if(i>0) {
				if(patientHistory==null){
					b=true;
				}else {
					ps=con.prepareStatement("UPDATE DAPATIENTS SET MED_HISTORY=? WHERE PATIENTID=?");
					ps.setString(1, patientHistory);
					ps.setInt(2, patientId);
					int j=ps.executeUpdate();
					System.out.println("Report Updated");
					if(j>0) {
						b=true;
					}
				}
			}
		}catch(Exception e){
			
		}
		return b;
	}

	@Override
	public List<AppointmentViewBean> getHistoryWithCouponNo(
			AppointmentViewBean viewBean) {
		String patientCouponNumber=viewBean.getPatientCouponNumber();
		ResultSet rs=null;
		Connection con=null;
		PreparedStatement ps=null;
		List<AppointmentViewBean> list=null;
		
		try {
			con=DBUtil.getConnection();
			System.out.println("Connection Established");
			ps=con.prepareStatement("SELECT PATIENTNAME,ROUND(MONTHS_BETWEEN(SYSDATE,DOB)/12) AGE, GENDER,TOKENNO,REASON,MED_HISTORY,REPORT FROM DAPATIENTS P,DAAPPOINTMENTS A WHERE P.PATIENTID=A.PATIENTID AND TOKENNO=?");
			ps.setString(1, patientCouponNumber);
			rs=ps.executeQuery();
			System.out.println("Query Executed");
			viewBean=null;
			list=new ArrayList<AppointmentViewBean>();
			while(rs.next()) {
				viewBean=new AppointmentViewBean();
				viewBean.setPatientName(rs.getString(1));
				viewBean.setPatientAge(rs.getInt(2));
				viewBean.setPatientGender(rs.getString(3));
				viewBean.setPatientCouponNumber(rs.getString(4));
				viewBean.setPatientReason(rs.getString(5));
				viewBean.setPatientHistory(rs.getString(6));
				viewBean.setPatientReport(rs.getString(7));
				System.out.println(viewBean.getPatientName());
				System.out.println(viewBean.getPatientAge());
				System.out.println(viewBean.getPatientCouponNumber());
				System.out.println(viewBean.getPatientGender());
				System.out.println(viewBean.getPatientHistory());
				System.out.println(viewBean.getPatientReason());
				System.out.println(viewBean.getPatientReport());
				System.out.println("History: "+viewBean.getPatientHistory());
				list.add(viewBean);
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}

	@Override
	public List<AppointmentViewBean> getHistoryWithNamePhone(
			AppointmentViewBean viewBean) {
		String patientName=viewBean.getPatientName();
		long patientPhone=viewBean.getPatientPhone();
		ResultSet rs=null;
		Connection con=null;
		PreparedStatement ps=null;
		List<AppointmentViewBean> list=null;
		try {
			con=DBUtil.getConnection();
			System.out.println("Connection Established");
			ps=con.prepareStatement("SELECT PATIENTNAME,ROUND(MONTHS_BETWEEN(SYSDATE,DOB)/12) AGE, GENDER,TOKENNO,REASON,MED_HISTORY,REPORT FROM DAPATIENTS P,DAAPPOINTMENTS A WHERE P.PATIENTID=A.PATIENTID and patientname=? and mobno=?");
			ps.setString(1, patientName);
			ps.setLong(2, patientPhone);
			rs=ps.executeQuery();
			System.out.println("Query Executed");
			viewBean=null;
			list=new ArrayList<AppointmentViewBean>();
			while(rs.next()) {
				viewBean=new AppointmentViewBean();
				viewBean.setPatientName(rs.getString(1));
				viewBean.setPatientAge(rs.getInt(2));
				viewBean.setPatientGender(rs.getString(3));
				viewBean.setPatientCouponNumber(rs.getString(4));
				viewBean.setPatientReason(rs.getString(5));
				viewBean.setPatientHistory(rs.getString(6));
				viewBean.setPatientReport(rs.getString(7));
				System.out.println(viewBean.getPatientName());
				System.out.println(viewBean.getPatientAge());
				System.out.println(viewBean.getPatientCouponNumber());
				System.out.println(viewBean.getPatientGender());
				System.out.println(viewBean.getPatientHistory());
				System.out.println(viewBean.getPatientReason());
				System.out.println(viewBean.getPatientReport());
				System.out.println("History: "+viewBean.getPatientHistory());
				list.add(viewBean);
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}

	@Override
	public List<AppointmentViewBean> getHistoryWithApptNo(
			AppointmentViewBean viewBean) {
		java.sql.Date patientAppointmentDate=viewBean.getAppointmentDate();
		ResultSet rs=null;
		Connection con=null;
		PreparedStatement ps=null;
		List<AppointmentViewBean> list=null;
		
		try {
			con=DBUtil.getConnection();
			System.out.println("Connection Established");
			ps=con.prepareStatement("SELECT PATIENTNAME,ROUND(MONTHS_BETWEEN(SYSDATE,DOB)/12) AGE, GENDER,TOKENNO,REASON,MED_HISTORY,REPORT FROM DAPATIENTS P,DAAPPOINTMENTS A WHERE P.PATIENTID=A.PATIENTID AND APPOINTMENT_DATE=?");
			ps.setDate(1, patientAppointmentDate);
			rs=ps.executeQuery();
			System.out.println("Query Executed");
			viewBean=null;
			list=new ArrayList<AppointmentViewBean>();
			while(rs.next()) {
				viewBean=new AppointmentViewBean();
				viewBean.setPatientName(rs.getString(1));
				viewBean.setPatientAge(rs.getInt(2));
				viewBean.setPatientGender(rs.getString(3));
				viewBean.setPatientCouponNumber(rs.getString(4));
				viewBean.setPatientReason(rs.getString(5));
				viewBean.setPatientHistory(rs.getString(6));
				viewBean.setPatientReport(rs.getString(7));
				System.out.println(viewBean.getPatientName());
				System.out.println(viewBean.getPatientAge());
				System.out.println(viewBean.getPatientCouponNumber());
				System.out.println(viewBean.getPatientGender());
				System.out.println(viewBean.getPatientHistory());
				System.out.println(viewBean.getPatientReason());
				System.out.println(viewBean.getPatientReport());
				System.out.println("History: "+viewBean.getPatientHistory());
				list.add(viewBean);
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return list;
	}
	
}
