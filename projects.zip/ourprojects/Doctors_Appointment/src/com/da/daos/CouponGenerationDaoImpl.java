package com.da.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.da.beans.CouponBean;


public class CouponGenerationDaoImpl implements CouponGenerationDao {
	public List<CouponBean> getDoctors(CouponBean bean) {
		int slot = bean.getSlot();
		java.sql.Date patientAppointmentDate = bean.getPatientAppointmentDate();
		System.out.println(slot + "    " + patientAppointmentDate);
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		List<CouponBean> li = null;
		String query = "select doctor_id, count(tokenno) no from daappointments where appointment_date=? and slot=? and doctor_id=? group by doctor_id";
		try {
			con = DBUtil.getConnection();
			System.out.println("Connection Established");
			ps = con.prepareStatement(query);
			ps.setDate(1, patientAppointmentDate);
			ps.setInt(2, slot);
			ps.setInt(3, 1);
			rs = ps.executeQuery();
			System.out.println("Executed Query");
			li = new ArrayList<CouponBean>();
			bean = null;
			if (rs.next()) {
				if (rs.getInt("no") < 30) {
					bean = new CouponBean();
					bean.setDoctorId(1);
					// System.out.println(bean.getDoctorId()+"  "+rs.getInt("no"));
					li.add(bean);
				}
			} else {
				bean = new CouponBean();
				bean.setDoctorId(1);
				// System.out.println("out         "+bean.getDoctorId());
				li.add(bean);
			}
			ps.close();
			ps = con.prepareStatement(query);
			ps.setDate(1, patientAppointmentDate);
			ps.setInt(2, slot);
			ps.setInt(3, 2);
			rs = ps.executeQuery();
			System.out.println("Executed Query");
			if (rs.next()) {
				if (rs.getInt("no") < 30) {
					bean = new CouponBean();
					bean.setDoctorId(2);
					// System.out.println("in         "+bean.getDoctorId());
					li.add(bean);
				}
			} else {
				bean = new CouponBean();
				bean.setDoctorId(2);
				// System.out.println("out            "+bean.getDoctorId());
				li.add(bean);
			}
			ps = con.prepareStatement(query);
			ps.setDate(1, patientAppointmentDate);
			ps.setInt(2, slot);
			ps.setInt(3, 3);
			rs = ps.executeQuery();
			System.out.println("Executed Query");
			if (rs.next()) {
				if (rs.getInt("no") < 30) {
					bean = new CouponBean();
					bean.setDoctorId(3);
					System.out.println(bean.getDoctorId());
					li.add(bean);
				}
			} else {
				bean = new CouponBean();
				bean.setDoctorId(3);
				System.out.println("out    " + bean.getDoctorId());
				li.add(bean);
			}
			// System.out.println(rs.isBeforeFirst());
			/*
			 * if (rs.isBeforeFirst()) { while (rs.next()) { if (rs.getInt("no")
			 * < 30) { bean = new CouponBean();
			 * bean.setDoctorId(rs.getInt("doctor_id"));
			 * System.out.println("Doctor avail: "+bean.getDoctorId());
			 * //bean.setNoOfAppointments(rs.getInt("no")); //
			 * System.out.println("No:"+rs.getInt("no"));
			 * 
			 * li.add(bean); } } }else { int i=1; while(i<=3){ bean = new
			 * CouponBean(); bean.setDoctorId(i); li.add(bean); i++; } }
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
		return li;
	}

	@Override
	public List<CouponBean> getCouponNumbers(CouponBean bean) {
		int slot = bean.getSlot();
		int doctorId = bean.getDoctorId();
		java.sql.Date patientAppointmentDate = bean.getPatientAppointmentDate();
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		List<CouponBean> li = null;
		String query = "select tokenno from daappointments where slot=? and appointment_date=? and doctor_id=? order by tokenno asc";
		try {
			con = DBUtil.getConnection();
			System.out.println("Connection Established");
			ps = con.prepareStatement(query);
			ps.setInt(1, slot);
			ps.setDate(2, patientAppointmentDate);
			ps.setInt(3, doctorId);
			rs = ps.executeQuery();
			System.out.println("Executed Query");
			li = new ArrayList<CouponBean>();
			bean = null;
			while (rs.next()) {
				bean = new CouponBean();
				bean.setPatientCouponNumber(rs.getString(1));
				li.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return li;
	}

	@Override
	public String getDoctorName(int doctorId) {
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		String doctorName=null;
		String query = "select name from dadoctors where id=?";
		try {
			con = DBUtil.getConnection();
			System.out.println("Connection Established");
			ps = con.prepareStatement(query);
			ps.setInt(1, doctorId);
			rs = ps.executeQuery();
			if (rs.next()) {
				doctorName = rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return doctorName;
	}
}
