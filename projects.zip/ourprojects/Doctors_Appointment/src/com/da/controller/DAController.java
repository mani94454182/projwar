package com.da.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.da.beans.AppointmentFixBean;
import com.da.beans.AppointmentTransferBean;
import com.da.beans.AppointmentViewBean;
import com.da.beans.CouponBean;
import com.da.beans.LoginBean;
import com.da.services.AppointmentFixService;
import com.da.services.AppointmentFixServiceImpl;
import com.da.services.AppointmentViewService;
import com.da.services.AppointmentViewServiceImpl;
import com.da.services.CouponGenerationService;
import com.da.services.CouponGenerationServiceImpl;
import com.da.services.LoginService;
import com.da.services.LoginServiceImpl;

public class DAController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HttpSession session = null;

	protected CouponBean generateDoctorId(HttpServletRequest request,
			HttpServletResponse response, int slot,
			java.sql.Date patientAppointmentDate) {
		Random ran = new Random();
		int i, selectedDoctor = -1;
		CouponBean couponBean = new CouponBean();
		couponBean.setSlot(slot);
		couponBean.setPatientAppointmentDate(patientAppointmentDate);
		CouponGenerationService generationService = new CouponGenerationServiceImpl();
		List<CouponBean> li = generationService.getDoctors(couponBean);
		int size = li.size();
		if (size == 3) {
			i = ran.nextInt(3);
			selectedDoctor = li.get(i).getDoctorId();
		} else if (size == 2) {
			i = ran.nextInt(2);
			selectedDoctor = li.get(i).getDoctorId();
		} else if (size == 1) {
			selectedDoctor = li.get(0).getDoctorId();
		}
		String selectedDoctorName=generationService.getDoctorName(selectedDoctor); 
		couponBean=new CouponBean();
		couponBean.setDoctorId(selectedDoctor);
		couponBean.setDoctorName(selectedDoctorName);
		return couponBean;
	}

	/******************************* Doctor Selection End ********************************************/
	protected String generateCoupon(HttpServletRequest request,
			HttpServletResponse response, String appointmentDate, int slot,
			int doctorId) {
		java.sql.Date patientAppointmentDate = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

			Date parser = sdf.parse(appointmentDate);
			patientAppointmentDate = new java.sql.Date(parser.getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}

		CouponBean couponBean = new CouponBean();
		couponBean.setPatientAppointmentDate(patientAppointmentDate);
		couponBean.setSlot(slot);
		couponBean.setDoctorId(doctorId);

		int i, selectedCoupon;
		String patientCouponNumber;

		patientCouponNumber = "" + doctorId;
		System.out.println("Selected Doctor is " + doctorId);
		CouponGenerationService generationService2 = new CouponGenerationServiceImpl();
		List<CouponBean> li = generationService2.getCouponNumbers(couponBean);
		selectedCoupon = 1;
		for (CouponBean b : li) {
			i = Integer.parseInt(b.getPatientCouponNumber().charAt(10) + ""
					+ b.getPatientCouponNumber().charAt(11));
			if (i == selectedCoupon) {
				selectedCoupon++;
			} else {
				break;
			}
		}
		StringTokenizer tokenizer = new StringTokenizer(appointmentDate, "-");
		while (tokenizer.hasMoreTokens()) {
			patientCouponNumber += tokenizer.nextToken();
		}
		if (selectedCoupon < 10) {
			patientCouponNumber += slot + "0" + selectedCoupon;
		} else {
			patientCouponNumber += slot + "" + selectedCoupon;
		}

		System.out.println(patientCouponNumber);
		return patientCouponNumber;
	}

	/******************************* Tokenno Generation End ********************************************/
	protected void reloadView(HttpServletRequest request,
			HttpServletResponse response, String userName)
			throws ServletException, IOException {
		AppointmentViewService viewService = new AppointmentViewServiceImpl();
		Date date = new Date();
		java.sql.Date now = new java.sql.Date(date.getTime());
		AppointmentViewBean viewBean = new AppointmentViewBean();
		viewBean.setAppointmentDate(now);
		viewBean.setDoctorsUserName(userName);
		List<AppointmentViewBean> list = viewService.getAppointments(viewBean);
		request.setAttribute("list", list);
		RequestDispatcher dispatcher = request
				.getRequestDispatcher("/View/Appointment_View.jsp");
		dispatcher.forward(request, response);
		// response.sendRedirect("/Doctors_Appointment/View/Appointment_View.jsp");
	}

	/******************************* Reload View End ********************************************/
	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String operation = request.getParameter("operation");
		System.out.println(operation);
		if (operation == null) {

			response.sendRedirect("/Doctors_Appointment/View/Login.jsp");
		} else if (operation.equals("login")) {
			PrintWriter pw = response.getWriter();
			String userName = request.getParameter("userName");
			String password = request.getParameter("password");
			LoginBean lb = new LoginBean();
			lb.setUserName(userName);
			lb.setPassword(password);
			LoginService loginService = new LoginServiceImpl();
			String userType = loginService.authenticate(lb);
			if (userType == null) {
				response.sendRedirect("/Doctors_Appointment/View/Login.jsp?Status=error");
			} else if (userType.equals("RECEPTIONIST")) {
				session = request.getSession();
				session.setAttribute("userId", userName);
				/*
				 * RequestDispatcher
				 * rd=request.getRequestDispatcher("/View/Appointment.jsp");
				 * rd.forward(request, response);
				 */
				response.sendRedirect("/Doctors_Appointment/View/Appointment_Fix.jsp");
			} else if (userType.equals("DOCTOR")) {
				session = request.getSession();
				session.setAttribute("userId", userName);
				reloadView(request, response, userName);
			}
		}
		/******************************* Login End ********************************************/
		else if (operation.equals("fix_appointment")) {
			session = request.getSession();
			// System.out.println(session.getAttribute("userId"));
			if (session.isNew()) {
				response.sendRedirect("/Doctors_Appointment/View/Login.jsp");
			}
			String patientName = request.getParameter("patientName");
			String dob = request.getParameter("patientDOB");
			String patientPhone = request.getParameter("patientPhone");
			String appt = request.getParameter("patientAppointmentDate");
			String patientMail = request.getParameter("patientMail");
			String patientAddress = request.getParameter("patientAddress");
			String patientReason = request.getParameter("patientReason");
			String patientGender = request.getParameter("patientGender");
			long phone = Long.parseLong(patientPhone);
			int slot = Integer.parseInt(request.getParameter("patientSlot"));
			java.sql.Date patientDOB = null;
			java.sql.Date patientAppointmentDate = null;
			// System.out.println(dob + " " + appt);
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

				Date parser = sdf.parse(dob);

				patientDOB = new java.sql.Date(parser.getTime());
				parser = sdf.parse(appt);
				patientAppointmentDate = new java.sql.Date(parser.getTime());
			} catch (Exception e) {
				e.printStackTrace();
			}
			CouponBean couponBean = generateDoctorId(request, response, slot,
					patientAppointmentDate);
			int doctorId=couponBean.getDoctorId();
			if(doctorId<0){
				response.sendRedirect("/Doctors_Appointment/View/Appointment_Fix.jsp?Status=error");
			}
			String patientCouponNumber = generateCoupon(request, response,
					appt, slot, doctorId);

			AppointmentFixBean bean = new AppointmentFixBean();
			bean.setDoctorId(doctorId);
			bean.setPatientAddress(patientAddress);
			bean.setPatientAppointmentDate(patientAppointmentDate);
			bean.setPatientCouponNumber(patientCouponNumber);
			bean.setPatientDOB(patientDOB);
			bean.setPatientMail(patientMail);
			bean.setPatientName(patientName);
			bean.setPatientPhone(phone);
			bean.setPatientSlot(slot);
			bean.setPatientReason(patientReason);
			bean.setPatientGender(patientGender);
			AppointmentFixService service = new AppointmentFixServiceImpl();
			boolean b = service.addAppointment(bean);
			if (b) {
				request.setAttribute("couponNo", patientCouponNumber);
				request.setAttribute("doctorName", couponBean.getDoctorName());
				RequestDispatcher rd=request.getRequestDispatcher("/View/Appointment_Fix.jsp");
				rd.forward(request, response);
				//response.sendRedirect("/Doctors_Appointment/View/Appointment_Fix.jsp?Status=success");
			} else {
				response.sendRedirect("/Doctors_Appointment/View/Appointment_Fix.jsp?Status=error");
			}
			/************************************ Appointment Fix End ***************************************/
		} else if (operation.equals("check")) {
			session = request.getSession();
			// System.out.println(session.getAttribute("userId"));
			if (session.isNew()) {
				response.sendRedirect("/Doctors_Appointment/View/Login.jsp");
			}
			String subOperation = request.getParameter("subOperation");
			AppointmentFixBean bean = new AppointmentFixBean();
			int patientId = -1;
			if (subOperation.equals("checkCoupon")) {
				String couponNumber = request
						.getParameter("patientCouponNumber");
				bean.setPatientCouponNumber(couponNumber);
				AppointmentFixService fixService = new AppointmentFixServiceImpl();
				patientId = fixService.checkPatientCoupon(bean);
			} else if (subOperation.equals("checkNamePhone")) {
				String patientName = request.getParameter("patientName");
				String phone = request.getParameter("patientPhone");
				long patientPhone = Long.parseLong(phone);
				bean.setPatientName(patientName);
				bean.setPatientPhone(patientPhone);
				AppointmentFixService fixService = new AppointmentFixServiceImpl();
				patientId = fixService.checkPatientName_Phone(bean);
			}

			if (patientId < 0) {
				response.sendRedirect("/Doctors_Appointment/View/Appointment_Fix_Existing.jsp?Status=error");
			} else {
				session.setAttribute("patientId", patientId);
				RequestDispatcher rd = request
						.getRequestDispatcher("View/Appointment_Fix_Existing_Details.jsp");
				rd.forward(request, response);
			}
			/******************************** Check Old Patient End *******************************************/
		} else if (operation.equals("fix_appointment_exist")) {
			session = request.getSession();
			// System.out.println(session.getAttribute("userId"));
			if (session.isNew()) {
				response.sendRedirect("/Doctors_Appointment/View/Login.jsp");
			}
			String patientId = request.getParameter("patientId");
			String patientSlot = request.getParameter("patientSlot");
			String patientApptDate = request
					.getParameter("patientAppointmentDate");
			String patientReason = request.getParameter("patientReason");
			int doctorId = 1;
			String patientCouponNumber = "" + Math.round(Math.random() * 100);
			System.out.println(patientCouponNumber);
			int pid = Integer.parseInt(patientId);
			int slot = Integer.parseInt(patientSlot);
			java.sql.Date patientAppointmentDate = null;
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

				Date parser = sdf.parse(patientApptDate);
				patientAppointmentDate = new java.sql.Date(parser.getTime());
			} catch (Exception e) {
				e.printStackTrace();
			}
			AppointmentFixBean bean = new AppointmentFixBean();
			bean.setDoctorId(doctorId);
			bean.setPatientAppointmentDate(patientAppointmentDate);
			bean.setPatientCouponNumber(patientCouponNumber);
			bean.setPatientId(pid);
			bean.setPatientSlot(slot);
			bean.setPatientReason(patientReason);
			AppointmentFixService fixService = new AppointmentFixServiceImpl();
			boolean b = fixService.addAppointmentOldPatient(bean);
			if (b) {
				response.sendRedirect("/Doctors_Appointment/View/Appointment_Fix_Existing_Details.jsp?Status=success");
			} else {
				response.sendRedirect("/Doctors_Appointment/View/Appointment_Fix_Existing_Details.jsp?Status=error");
			}
		}
		/******************************** Old Patient Appointment Fixed *******************************************/
		else if (operation.equals("update")) {
			session = request.getSession();
			// System.out.println(session.getAttribute("userId"));
			if (session.isNew()) {
				response.sendRedirect("/Doctors_Appointment/View/Login.jsp");
			}

			String pId = request.getParameter("patientId");
			String patientHistory = request.getParameter("patientHistory");
			String patientReport = request.getParameter("patientReport");
			int patientId = Integer.parseInt(pId);
			System.out.println(patientId);
			System.out.println(patientHistory);
			System.out.println(patientReport);
			AppointmentViewBean viewBean = new AppointmentViewBean();
			Date date = new Date();
			java.sql.Date now = new java.sql.Date(date.getTime());
			viewBean = new AppointmentViewBean();
			viewBean.setAppointmentDate(now);
			viewBean.setPatientHistory(patientHistory);
			viewBean.setPatientId(patientId);
			viewBean.setPatientReport(patientReport);
			AppointmentViewService viewService = new AppointmentViewServiceImpl();
			boolean b = viewService.updateAppointments(viewBean);
			if (b) {
				String userName = (String) session.getAttribute("userId");
				reloadView(request, response, userName);

			} else {
				System.out.println("Failed update");
			}
		}
		/******************************** Update Appointment Ended *******************************************/
		else if (operation.equals("history")) {
			String subOperation = request.getParameter("subOperation");
			AppointmentViewBean viewBean = new AppointmentViewBean();
			List<AppointmentViewBean> li = null;
			if (subOperation.equals("historyCoupon")) {
				String couponNumber = request
						.getParameter("patientCouponNumber");
				viewBean.setPatientCouponNumber(couponNumber);
				AppointmentViewService fixService = new AppointmentViewServiceImpl();
				li = fixService.getHistoryWithCouponNo(viewBean);
			} else if (subOperation.equals("historyNamePhone")) {
				String patientName = request.getParameter("patientName");
				String phone = request.getParameter("patientPhone");
				long patientPhone = Long.parseLong(phone);
				viewBean.setPatientName(patientName);
				viewBean.setPatientPhone(patientPhone);
				AppointmentViewService fixService = new AppointmentViewServiceImpl();
				li = fixService.getHistoryWithNamePhone(viewBean);

			} else if (subOperation.equals("historyAppt")) {
				String patientApptDate = request
						.getParameter("patientAppointmentDate");
				java.sql.Date patientAppointmentDate = null;
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
					Date parser = sdf.parse(patientApptDate);
					patientAppointmentDate = new java.sql.Date(parser.getTime());
				} catch (Exception e) {
					e.printStackTrace();
				}
				viewBean.setAppointmentDate(patientAppointmentDate);
				AppointmentViewService fixService = new AppointmentViewServiceImpl();
				li = fixService.getHistoryWithApptNo(viewBean);
			}
			request.setAttribute("list", li);
			if (!li.isEmpty()) {
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("/View/Appointment_History.jsp");
				dispatcher.forward(request, response);
			} else {
				response.sendRedirect("/Doctors_Appointment/View/Appointment_History.jsp?Status=error");
			}
			/******************************** History of Appointment Ended *******************************************/
		} else if (operation.equals("Today's Appointments")) {
			session = request.getSession();
			if (session.isNew()) {
				response.sendRedirect("/Doctors_Appointment/View/Login.jsp");
			}
			String userName = (String) session.getAttribute("userId");
			reloadView(request, response, userName);
			/******************************** Today's Appointment Directed Ended *******************************************/
		} else if (operation.equals("transfer_check")) {
			session = request.getSession();
			// System.out.println(session.getAttribute("userId"));
			if (session.isNew()) {
				response.sendRedirect("/Doctors_Appointment/View/Login.jsp");
			}
			System.out.println("inside controller");
			String subOperation = request.getParameter("subOperation");
			AppointmentFixBean bean = new AppointmentFixBean();
			AppointmentTransferBean transferBean=new AppointmentTransferBean();
			if (subOperation.equals("checkCoupon")) {
				String couponNumber = request
						.getParameter("patientCouponNumber");
				bean.setPatientCouponNumber(couponNumber);
				AppointmentFixService fixService = new AppointmentFixServiceImpl();
				 transferBean = fixService
						.transferCheckPatientCoupon(bean);
			} else if (subOperation.equals("checkNamePhone")) {
				String patientName = request.getParameter("patientName");
				String phone = request.getParameter("patientPhone");
				long patientPhone = Long.parseLong(phone);
				String patientApptDate = request
						.getParameter("patientAppointmentDate");
				java.sql.Date patientAppointmentDate = null;
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
					Date parser = sdf.parse(patientApptDate);
					patientAppointmentDate = new java.sql.Date(parser.getTime());
				} catch (Exception e) {
					e.printStackTrace();
				}

				bean.setPatientAppointmentDate(patientAppointmentDate);
				bean.setPatientName(patientName);
				bean.setPatientPhone(patientPhone);
				AppointmentFixService fixService = new AppointmentFixServiceImpl();
				transferBean = fixService
						.transferCheckPatientName_Phone(bean);

			}
			if (transferBean != null) {
				session.setAttribute("oldCoupon", transferBean);
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("/View/Appointment_Transfer.jsp");
				dispatcher.forward(request, response);
			} else {
				response.sendRedirect("/Doctors_Appointment/View/Appointment_Transfer.jsp?Status=error");
			}
		}else if(operation.equals("Transfer")) {
			session=request.getSession();
			AppointmentTransferBean transferBean=(AppointmentTransferBean)session.getAttribute("oldCoupon");
			StringTokenizer str=new StringTokenizer(transferBean.getAppointmentDate(),"- ");
			String string[]=new String[3];
			int i=0;
				while(str.hasMoreTokens()&&i<3){
					string[i]=str.nextToken();
					i++;
				}
			String appointmentDate=string[2]+"-"+string[1]+"-"+string[0];
			System.out.println("Date: "+appointmentDate);
			int slot;
			if(transferBean.getSlot()==1){
				 slot=2;
			}else {
				 slot=1;
			}
			System.out.println("Selected Slot: "+slot);
			System.out.println(transferBean.getAppointmentDate());
			CouponBean couponBean=generateDoctorId(request, response, slot,
					transferBean.getPatientAppointmentDate());
			int doctorId = couponBean.getDoctorId();
			if(doctorId<0){
				response.sendRedirect("/Doctors_Appointment/View/Appointment_Transfer.jsp?Status=error");
			}
			String patientCouponNumber = generateCoupon(request, response, appointmentDate, slot, doctorId);
			
			transferBean.setNewCouponNumber(patientCouponNumber);
			transferBean.setSlot(slot);
			transferBean.setDoctorId(doctorId);
			AppointmentFixService fixService=new AppointmentFixServiceImpl();
			boolean b=fixService.transfer(transferBean);
			if(b){
				session.removeAttribute("oldCoupon");
				request.setAttribute("doctorName", couponBean.getDoctorName());
				request.setAttribute("newCouponNumber", patientCouponNumber);
				RequestDispatcher dispatcher = request
				.getRequestDispatcher("/View/Appointment_Transfer.jsp");
		dispatcher.forward(request, response);
			}else {
				session.removeAttribute("oldCoupon");
				response.sendRedirect("/Doctors_Appointment/View/Appointment_Transfer.jsp?Status=error");
			}
		}
		/*
		 * else if(operation.equals("coupongen")) { java.sql.Date
		 * patientAppointmentDate = null; try { SimpleDateFormat sdf = new
		 * SimpleDateFormat("dd-MM-yyyy");
		 * 
		 * Date parser = sdf.parse("05-12-2014"); patientAppointmentDate = new
		 * java.sql.Date(parser.getTime()); } catch (Exception e) {
		 * e.printStackTrace(); }
		 * 
		 * int doctorId=generateDoctorId(request, response, 1,
		 * patientAppointmentDate); String
		 * patientCouponNumber=generateCoupon(request, response, "05-12-2014",
		 * 1,doctorId); }
		 */
	}

}
