package com.da.models;

import com.da.beans.LoginBean;

public interface LoginModel {
	public String authenticate(LoginBean bean);
}
