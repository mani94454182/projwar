package com.da.beans;


public class AppointmentFixBean {
	private String patientName;
	private java.sql.Date patientDOB;
	private int patientSlot;
	private java.sql.Date patientAppointmentDate;
	private long patientPhone;
	private String patientMail;
	private String patientAddress;
	private String patientReason;
	private int doctorId;
	private String patientCouponNumber;
	private String patientGender;
	private int patientId;
	
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	
	public int getPatientSlot() {
		return patientSlot;
	}
	public void setPatientSlot(int patientSlot) {
		this.patientSlot = patientSlot;
	}
	
	public java.sql.Date getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(java.sql.Date patientDOB) {
		this.patientDOB = patientDOB;
	}
	public java.sql.Date getPatientAppointmentDate() {
		return patientAppointmentDate;
	}
	public void setPatientAppointmentDate(java.sql.Date patientAppointmentDate) {
		this.patientAppointmentDate = patientAppointmentDate;
	}
	public long getPatientPhone() {
		return patientPhone;
	}
	public void setPatientPhone(long patientPhone) {
		this.patientPhone = patientPhone;
	}
	public String getPatientMail() {
		return patientMail;
	}
	public void setPatientMail(String patientMail) {
		this.patientMail = patientMail;
	}
	public String getPatientAddress() {
		return patientAddress;
	}
	public void setPatientAddress(String patientAddress) {
		this.patientAddress = patientAddress;
	}
	public String getPatientReason() {
		return patientReason;
	}
	public void setPatientReason(String patientReason) {
		this.patientReason = patientReason;
	}
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	
	
	public String getPatientCouponNumber() {
		return patientCouponNumber;
	}
	public void setPatientCouponNumber(String patientCouponNumber) {
		this.patientCouponNumber = patientCouponNumber;
	}
	public String getPatientGender() {
		return patientGender;
	}
	public void setPatientGender(String patientGender) {
		this.patientGender = patientGender;
	}
	
}
