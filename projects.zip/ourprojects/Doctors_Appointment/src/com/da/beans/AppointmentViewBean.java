package com.da.beans;

public class AppointmentViewBean {
	private String patientName;
	private int patientAge;
	private String patientGender;
	private String patientReason;
	private String patientCouponNumber;
	private int patientId;
	private String doctorsUserName;
	private java.sql.Date appointmentDate;
	private String patientHistory;
	private int patientSlot;
	private String patientReport;
	private long patientPhone;
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public int getPatientAge() {
		return patientAge;
	}
	public void setPatientAge(int patientAge) {
		this.patientAge = patientAge;
	}
	public String getPatientGender() {
		return patientGender;
	}
	public void setPatientGender(String patientGender) {
		this.patientGender = patientGender;
	}
	public String getPatientReason() {
		return patientReason;
	}
	public void setPatientReason(String patientReason) {
		this.patientReason = patientReason;
	}
	public String getPatientCouponNumber() {
		return patientCouponNumber;
	}
	public void setPatientCouponNumber(String patientCouponNumber) {
		this.patientCouponNumber = patientCouponNumber;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getDoctorsUserName() {
		return doctorsUserName;
	}
	public void setDoctorsUserName(String doctorsUserName) {
		this.doctorsUserName = doctorsUserName;
	}
	public java.sql.Date getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(java.sql.Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getPatientHistory() {
		return patientHistory;
	}
	public void setPatientHistory(String patientHistory) {
		this.patientHistory = patientHistory;
	}
	public int getPatientSlot() {
		return patientSlot;
	}
	public void setPatientSlot(int patientSlot) {
		this.patientSlot = patientSlot;
	}
	public String getPatientReport() {
		return patientReport;
	}
	public void setPatientReport(String patientReport) {
		this.patientReport = patientReport;
	}
	public long getPatientPhone() {
		return patientPhone;
	}
	public void setPatientPhone(long patientPhone) {
		this.patientPhone = patientPhone;
	}
	
}
