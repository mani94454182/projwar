package com.da.beans;

public class CouponBean {
	private int doctorId;
	private String patientCouponNumber;
	private java.sql.Date patientAppointmentDate;
	private int slot;
	private int noOfAppointments;
	private String doctorName;
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public String getPatientCouponNumber() {
		return patientCouponNumber;
	}
	public void setPatientCouponNumber(String patientCouponNumber) {
		this.patientCouponNumber = patientCouponNumber;
	}
	public java.sql.Date getPatientAppointmentDate() {
		return patientAppointmentDate;
	}
	public void setPatientAppointmentDate(java.sql.Date patientAppointmentDate) {
		this.patientAppointmentDate = patientAppointmentDate;
	}
	public int getSlot() {
		return slot;
	}
	public void setSlot(int slot) {
		this.slot = slot;
	}
	public int getNoOfAppointments() {
		return noOfAppointments;
	}
	public void setNoOfAppointments(int noOfAppointments) {
		this.noOfAppointments = noOfAppointments;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	
}
