package com.da.beans;

public class AppointmentTransferBean {
	private String appointmentDate;
	private int slot;
	private java.sql.Date patientAppointmentDate;
	private String oldCouponNumber;
	private String newCouponNumber;
	private int doctorId;
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public int getSlot() {
		return slot;
	}
	public void setSlot(int slot) {
		this.slot = slot;
	}
	public java.sql.Date getPatientAppointmentDate() {
		return patientAppointmentDate;
	}
	public void setPatientAppointmentDate(java.sql.Date patientAppointmentDate) {
		this.patientAppointmentDate = patientAppointmentDate;
	}
	public String getOldCouponNumber() {
		return oldCouponNumber;
	}
	public void setOldCouponNumber(String oldCouponNumber) {
		this.oldCouponNumber = oldCouponNumber;
	}
	public String getNewCouponNumber() {
		return newCouponNumber;
	}
	public void setNewCouponNumber(String newCouponNumber) {
		this.newCouponNumber = newCouponNumber;
	}
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	
}
