function validate() {
	var username=document.getElementById("userId").value;
	var pass=document.getElementById("pwdId").value;
	var invalid=" ";
	var msg=document.getElementById("msgId");
	if(document.getElementById("userId").value=="Username") {
		username="";
	}
	if(document.getElementById("pwdId").value=="Password") {
		pass="";
	}
	if(username=="") {
		//alert("Please Enter Username");
		msg.innerHTML="Please Enter Username";
		return false;
	}else if(pass=="") {
		//alert("Please Enter Password");
		msg.innerHTML="Please Enter Password";
		return false;
	}else if(username.indexOf(invalid)>-1 || pass.indexOf(invalid)>-1) {
		//alert("Sorry, spaces are not allowed in username and password");
		msg.innerHTML="Sorry, spaces are not allowed in username and password";
		return false;
	} else {
		return true;
	}
}