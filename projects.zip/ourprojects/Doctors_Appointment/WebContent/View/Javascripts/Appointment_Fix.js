function validate() {
	//alert();
	var msg=document.getElementById("msgId");
	var patientName=document.getElementById("pNameId");
	var DOB=document.getElementById("pDobId");
	var appointmentDate=document.getElementById("pApptId");
	var phoneNo=document.getElementById("pPhoneId");
	var mail=document.getElementById("pMailId");
	var address=document.getElementById("pAddressId");
	var reason=document.getElementById("pReasonId");
	if(patientName.value=="") {
		msg.innerHTML="Patient Name Field is Empty";
		return false;
	}else if(DOB.value=="") {
		msg.innerHTML="Date of Birth Field is Empty";
		return false;
	}else if(appointmentDate.value=="") {
		msg.innerHTML="Appointment Date Field is Empty";
		return false;
	}else if(phoneNo.value=="") {
		msg.innerHTML="Phone No. Field is Empty";
		return false;
	}else if(mail.value=="") {
		msg.innerHTML="Email Id Field is Empty";
		return false;
	}else if(address.value=="") {
		msg.innerHTML="Address Field is Empty";
		return false;
	}else if(reason.value=="") {
		msg.innerHTML="Reason Field is Empty";
		return false;
	}
}

/*--------------------------------------------------*/
function isString(tag)
{

		var name=document.getElementById(tag.id);
		/*if(!isNaN(name.value.charAt(name.value.length-1)))
		{
			name.value="";

		}*/
		var letters=/^[a-zA-Z]+$/;
		if(!name.value.match(letters)) {
			name.value="";
			//document.getElementById("msgId").innerHTML="Enter a valid Name";
		}
}

function mobval()
{
	var mobno=document.getElementById("pPhoneId");
	if(mobno.value.length<10)
	{
		mobno.value="";
		document.getElementById("msgId").innerHTML="Enter a valid Mobile Number";
		return false;
	}
	else if(isNaN(mobno.value.charAt(9)))
	{
		document.getElementById("msgId").innerHTML="Enter a valid Mobile Number";
		mobno.value="";
		return false;
	}
}

function isNumber(tag) {
	
		var no=document.getElementById(tag.id);
		var numbers=/^[0-9]+$/;
		if(!no.value.match(numbers))
		{
			no.value="";
				//document.getElementById("msgId").innerHTML="Enter a valid Number";
		}
	
}

function blurnumCheck(tag)
{
	var val=document.getElementById(tag.id);
	var i=0;
	var letters=/^[a-zA-Z]+$/;
	for(i=0;i<val.value.length;i++)
	{
		if(!val.value.charAt(i).match(letters))
		{
			val.value="";
			document.getElementById("msgId").innerHTML="Enter only alphabets in Patient Name field";
			return false;
		}
	}
}

/*function blurcharCheck(tag)
{
	var val=document.getElementById(tag.id);
	var i=0;
	for(i=0;i<val.value.length;i++)
	{
		if(isNaN(val.value.charAt(i)))
		{
			val.value="";
			document.getElementById("msgId").innerHTML="Enter only Numbers";
			return false;
		}
	}
}*/

function mailCheck() {
	    var email = document.getElementById('pMailId');
	    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z\-])+\.)+([a-zA-Z]{2,3})+$/;

	    if (!filter.test(email.value)) {
	    	document.getElementById("msgId").innerHTML="Please provide a valid email address";
	    email.focus;
	    return false;
	   }
}
