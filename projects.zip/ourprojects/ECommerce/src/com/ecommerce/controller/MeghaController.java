package com.ecommerce.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet(name="online",urlPatterns="/")
public class MeghaController extends HttpServlet
{
	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("This is Init Method");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		RequestDispatcher rd= null;
		//step1 Collect the user Details?
		
		//res.getWriter().println("Servlet Hi");
		String uname=req.getParameter("uname");
		String upass=req.getParameter("upass");
		
		//step 2 Data Conversion
		int password=0;
		try {
			password=Integer.parseInt(upass);
		}catch(NumberFormatException nfe) {
			nfe.printStackTrace();
		}
		
		//step3 Manually Static Validation
		if((uname.equals("Megha")) && (password==12345)) {
			
			rd = req.getRequestDispatcher("/views/adminOPeration.jsp");
			rd.forward(req, res);
			//rd.include(req, res);
			
		//	res.getWriter().println("Success");
				
		}else {
			rd = req.getRequestDispatcher("/views/loginError.jsp");
			rd.forward(req, res);
			
			//res.getWriter().println("Error");
		}
		
	}
	
	@Override
	public void destroy() {
		
	}	

}
