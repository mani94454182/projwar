package com.hms.service;

import org.springframework.stereotype.Controller;

@Controller
public class LoginPageService {
	
	

}
