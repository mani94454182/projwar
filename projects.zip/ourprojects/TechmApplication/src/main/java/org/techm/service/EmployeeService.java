package org.techm.service;

import org.techm.model.Employee;

public class EmployeeService {
	public Employee getEmployeeDetails() {
		
		Employee em1= new Employee(111,"Megha",2300f);
		
		return em1;

}
}
